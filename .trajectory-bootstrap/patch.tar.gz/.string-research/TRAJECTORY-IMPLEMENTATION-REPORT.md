# Trajectory implementation report — one path object, two physical bodies

**Base:** `agent/weave-string-network@352bb2d25bb093bb84a11a9740051b0fa8e73a1b`  
**Decision:** organize music and engine work around continuous gesture over a
persistent body.

## Landed in this branch

- `SPEC-TRAJECTORY.md`: binding distinction between controls, direct
  trajectories, and inverse gestures.
- `mus-trajectory`: runtime-neutral Rust IR, state semantics, analytic
  kinematic checks, deterministic lowering, typed refusals, receipts, and
  float-bit-exact semantic/frame digests.
- `mus_analysis.trajectory`: Python oracle implementing the same digest and
  compiler, plus the MUS inline parser, string reference lowering, and real
  GARGANTA area-function adapter.
- Three JSON Schemas and a pinned cross-runtime fixture.
- `mus_dsp::trajectory`: live string-network adapter using the existing
  `ControlFrame` executor and native persistent linear pitch path.
- Rust unit/integration tests and a runnable `trajectory_etude` example.
- String and `/ba/` example programs.
- Python acceptance suite: 10 tests green in the construction environment.

Pinned identity:

```text
program sha256:f863212b5f40a0158719a4298d766bd4da41ccfdfb8430cbfd7654d03a7efc6d
frames  sha256:9604d346ac8ad35e338a3bffef75cd45ee887f57a774536bdc333207b0e23a0e
```

## What this resolves

The score-facing surface can name continuous physical motion without pretending
the inverse metric problem is solved. Weave/Guitar and GARGANTA share one
content-addressed path object. The current `ControlFrame` seam becomes a body
adapter detail, while Threader and the inverse gesture compiler gain a stable
output type.

## Withheld claims

- The complete `mus-engine` event walk does not yet invoke the new inline
  splitter; live execution is exposed through `mus_dsp::trajectory` and its
  example/tests.
- Variable-rank pitch transport is not certified. The accepted two-knot linear
  path uses native retuning but carries integer-delay and sideband obligations;
  strict mode refuses it.
- Direct tract-section closure is an experiment oracle, not the G2 derived
  closure/burst law.
- G1 fast passage, G3 self-oscillating folds, and G5 stochastic work remain
  open and are not promoted by trajectory execution.
- Rust was not available in the construction container; repository CI is the
  execution oracle for formatting, clippy, and release tests.

## Immediate continuation

Wire `mus-engine::source` to the adapter and join the trajectory receipt into
render/check output. Then run GARGANTA P2 in this IR and attack the pitch/
variable-delay connection, because the same result serves Weave trajectories,
vibrato, speech prosody, and Threader output.
